# Animated Background

A Pen created on CodePen.io. Original URL: [https://codepen.io/MarcoGuglielmelli/pen/ExGYae](https://codepen.io/MarcoGuglielmelli/pen/ExGYae).

Full-page background made with JavaScript and Canvas: the animation follows movement on non-touch devices

Based on: http://tympanus.net/Development/AnimatedHeaderBackgrounds/